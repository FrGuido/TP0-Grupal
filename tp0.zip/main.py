import menu_texto
import menu


menu_texto.bienvenida()
menu.login()

